﻿using System;
using System.Collections.Generic;

class Program
{
    static List<string> listaTareas = new List<string>();

    static void Main()
    {
        while (true)
        {
            Console.WriteLine("Menú de Tareas:");
            Console.WriteLine("1. Mostrar");
            Console.WriteLine("2. Agregar");
            Console.WriteLine("3. Eliminar");
            Console.WriteLine("4. Salir");
            Console.Write("Seleccione una opción: ");

            if (int.TryParse(Console.ReadLine(), out int opcion))
            {
                switch (opcion)
                {
                    case 1:
                        MostrarTareas();
                        break;
                    case 2:
                        AgregarTarea();
                        break;
                    case 3:
                        EliminarTarea();
                        break;
                    case 4:
                        Console.WriteLine("¡Hasta luego!");
                        return;
                    default:
                        Console.WriteLine("Opción inválida. Intente nuevamente.");
                        break;
                }
            }
            else
            {
                Console.WriteLine("Entrada inválida. Intente nuevamente.");
            }
        }
    }

    static void MostrarTareas()
    {
        Console.WriteLine("\nLista de Tareas:");
        for (int i = 0; i < listaTareas.Count; i++)
        {
            Console.WriteLine($"{i + 1}. {listaTareas[i]}");
        }
        Console.WriteLine();
    }

    static void AgregarTarea()
    {
        Console.Write("Ingrese la nueva tarea: ");
        string nuevaTarea = Console.ReadLine();
        listaTareas.Add(nuevaTarea);
        Console.WriteLine("Tarea agregada exitosamente.\n");
    }

    static void EliminarTarea()
    {
        MostrarTareas();
        Console.Write("Seleccione el número de la tarea a eliminar: ");
        if (int.TryParse(Console.ReadLine(), out int indice) && indice >= 1 && indice <= listaTareas.Count)
        {
            listaTareas.RemoveAt(indice - 1);
            Console.WriteLine("Tarea eliminada exitosamente.\n");
        }
        else
        {
            Console.WriteLine("Índice inválido. Intente nuevamente.\n");
        }
    }
}
