﻿using System;

class Program
{
    static void Main()
    {
        decimal[,] montosCompras = new decimal[5, 5];

        for (int cliente = 0; cliente < 5; cliente++)
        {
            for (int compra = 0; compra < 5; compra++)
            {
                Console.Write($"Ingrese el monto de la compra {compra + 1} para el cliente {cliente + 1}: ");
                if (!decimal.TryParse(Console.ReadLine(), out montosCompras[cliente, compra]))
                {
                    Console.WriteLine("Entrada inválida. Por favor, ingrese un número válido.");
                    compra--; // Reintentar la misma compra
                }
            }
        }

        CalcularDescuentos(montosCompras);
    }

    static void CalcularDescuentos(decimal[,] montosCompras)
    {
        int numClientes = montosCompras.GetLength(0);
        int numCompras = montosCompras.GetLength(1);

        for (int cliente = 0; cliente < numClientes; cliente++)
        {
            decimal totalCompra = 0;

            for (int compra = 0; compra < numCompras; compra++)
            {
                totalCompra += montosCompras[cliente, compra];
            }

            decimal descuento = 0;

            if (totalCompra >= 100 && totalCompra <= 999)
            {
                descuento = totalCompra * 0.1m;
            }
            else if (totalCompra >= 1000)
            {
                descuento = totalCompra * 0.2m;
            }

            decimal totalConDescuento = totalCompra - descuento;

            Console.WriteLine($"Cliente {cliente + 1}:");
            Console.WriteLine($"Total de compras: {totalCompra:C}");
            Console.WriteLine($"Descuento aplicado: {descuento:C}");
            Console.WriteLine($"Total a pagar (con descuento): {totalConDescuento:C}");
            Console.WriteLine();
        }
    }
}

