﻿using System;

namespace DemoTresEnLinea
{
    internal class Program
    {
        const char disponible = '_';
        const char jugador = 'X';
        const char maquina = 'O';
        char[,] tablero =
        {
            {disponible, disponible, disponible },
            {disponible, disponible, disponible },
            {disponible, disponible, disponible }
        };

        static void Main(string[] args)
        {
            Program p = new Program();
            bool fin = false;
            char jugadorActual = jugador;

            do
            {
                if (jugadorActual == jugador)
                {
                    p.RealizarJugada(jugadorActual);
                }
                else
                {
                    p.RealizarJugadaMaquina();
                }

                p.MostrarTablero();

                fin = p.TableroLleno() || p.EsGanador(jugadorActual);
                jugadorActual = (jugadorActual == jugador) ? maquina : jugador;
            } while (!fin);

            Console.ReadKey();
        }

        private void RealizarJugada(char jugadorActual)
        {
            Console.WriteLine($"Turno del jugador {jugadorActual}. Ingresa la fila (0-2):");
            int fila = int.Parse(Console.ReadLine());

            Console.WriteLine($"Ingresa la columna (0-2):");
            int columna = int.Parse(Console.ReadLine());

            if (tablero[fila, columna] == disponible)
            {
                tablero[fila, columna] = jugadorActual;
            }
            else
            {
                Console.WriteLine("¡Esa casilla ya está ocupada! Intenta de nuevo.");
                RealizarJugada(jugadorActual);
            }
        }

        private void RealizarJugadaMaquina()
        {
     
            for (int f = 0; f < 3; f++)
            {
                for (int c = 0; c < 3; c++)
                {
                    if (tablero[f, c] == disponible)
                    {
                        tablero[f, c] = maquina;
                        return;
                    }
                }
            }
        }

        private void MostrarTablero()
        {
            Console.WriteLine("\nTablero:");
            for (int f = 0; f < 3; f++)
            {
                for (int c = 0; c < 3; c++)
                {
                    Console.Write(tablero[f, c] + " ");
                }
                Console.WriteLine();
            }
        }

        private bool EsGanador(char jugadorActual)
        {

            if ((tablero[0, 0] == jugadorActual && tablero[1, 1] == jugadorActual && tablero[2, 2] == jugadorActual) ||
                (tablero[0, 2] == jugadorActual && tablero[1, 1] == jugadorActual && tablero[2, 0] == jugadorActual))
            {
                Console.WriteLine($"¡Felicidades jugador {jugadorActual}! ¡Eres el Ganador!");
                return true;
            }

            for (int i = 0; i < 3; i++)
            {
                if (tablero[i, 0] == jugadorActual && tablero[i, 1] == jugadorActual && tablero[i, 2] == jugadorActual)
                {
                    Console.WriteLine($"¡Felicidades jugador {jugadorActual}! ¡Eres el Ganador!");
                    return true;
                }
                if (tablero[0, i] == jugadorActual && tablero[1, i] == jugadorActual && tablero[2, i] == jugadorActual)
                {
                    Console.WriteLine($"¡Felicidades jugador {jugadorActual}! ¡Eres el Ganador!");
                    return true;
                }
            }
            return false;
        }

        private bool TableroLleno()
        {
            for (int f = 0; f < 3; f++)
            {
                for (int c = 0; c < 3; c++)
                {
                    if (tablero[f, c] == disponible)
                    {
                        return false;
                    }
                }
            }
            Console.WriteLine("¡Empate! El tablero está lleno.");
            return true;
        }
    }
}
